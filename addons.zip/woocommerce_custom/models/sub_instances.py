from odoo import models, fields
from woocommerce import API
from odoo.exceptions import UserError
